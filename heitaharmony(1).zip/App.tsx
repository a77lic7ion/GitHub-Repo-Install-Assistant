
import React, { useState } from 'react';
import { PromptCategory } from './types';
import { SENTENCES, QUESTIONS, PASSAGES } from './constants/prompts';
import { PromptContainer } from './components/PromptContainer';
import { ModelDownloader } from './components/ModelDownloader';
import { WelcomeSlides } from './components/WelcomeSlides';
import { IconMicrophone } from './components/icons';

const App: React.FC = () => {
  const [mode, setMode] = useState<PromptCategory | null>(null);
  const [showWelcome, setShowWelcome] = useState(!localStorage.getItem('hasSeenWelcome'));

  const handleWelcomeComplete = () => {
    localStorage.setItem('hasSeenWelcome', 'true');
    setShowWelcome(false);
  };

  const buttonClasses = (isActive: boolean) =>
    `px-6 py-3 rounded-lg text-lg font-semibold transition-all duration-300 flex items-center justify-center gap-3 w-full md:w-auto focus:outline-none focus:ring-4 focus:ring-opacity-50 ${
      isActive
        ? 'bg-orange-500 text-white shadow-lg scale-105 focus:ring-orange-400'
        : 'bg-gray-800 text-gray-300 hover:bg-gray-700 hover:text-white focus:ring-gray-600'
    }`;

  const renderContent = () => {
    if (showWelcome) {
        return <WelcomeSlides onComplete={handleWelcomeComplete} />;
    }
      
    if (!mode) {
      return (
        <div className="text-center animate-fade-in">
          <IconMicrophone className="w-24 h-24 mx-auto text-gray-600 mb-6" />
          <h2 className="text-3xl font-bold text-white mb-2">Welcome to HeitaHarmony</h2>
          <p className="text-gray-400 max-w-2xl mx-auto mb-10">
            Your participation helps improve speech recognition for diverse South African accents. Please choose a category to begin recording.
          </p>
          <div className="flex flex-col md:flex-row justify-center items-center gap-6">
            <button className={buttonClasses(false)} onClick={() => setMode(PromptCategory.Sentences)}>Sentences</button>
            <button className={buttonClasses(false)} onClick={() => setMode(PromptCategory.Questions)}>Questions</button>
            <button className={buttonClasses(false)} onClick={() => setMode(PromptCategory.Passages)}>Passages</button>
            <button className={buttonClasses(false)} onClick={() => setMode(PromptCategory.Models)}>Models</button>
          </div>
        </div>
      );
    }

    switch (mode) {
      case PromptCategory.Sentences:
        return <PromptContainer category={PromptCategory.Sentences} prompts={SENTENCES} onBack={() => setMode(null)} />;
      case PromptCategory.Questions:
        return <PromptContainer category={PromptCategory.Questions} prompts={QUESTIONS} onBack={() => setMode(null)} />;
      case PromptCategory.Passages:
        return <PromptContainer category={PromptCategory.Passages} prompts={PASSAGES} onBack={() => setMode(null)} />;
      case PromptCategory.Models:
        return <ModelDownloader onBack={() => setMode(null)} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-start sm:justify-center p-4 pt-8 sm:p-6 lg:p-8">
      <div className="w-full max-w-4xl mx-auto">
        <header className="w-full text-center mb-8">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-600">
            HeitaHarmony
          </h1>
        </header>
        <main className="bg-gray-900/50 rounded-2xl shadow-2xl p-6 sm:p-8 backdrop-blur-sm border border-gray-700">
          {renderContent()}
        </main>
        <footer className="text-center mt-8 text-gray-500 text-sm">
            <p>Training your voice for better AI transcripts.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
