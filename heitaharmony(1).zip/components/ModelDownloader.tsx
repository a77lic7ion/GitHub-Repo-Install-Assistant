
import React from 'react';
import { IconChevronLeft, IconDownload } from './icons';

interface ModelDownloaderProps {
  onBack: () => void;
}

const modelFileUrl = 'https://github.com/ggerganov/whisper.cpp/releases/download/v1.5.5/ggml-tiny.bin';

export const ModelDownloader: React.FC<ModelDownloaderProps> = ({ onBack }) => {
  return (
    <div className="flex flex-col gap-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <button onClick={onBack} className="text-gray-400 hover:text-white transition-colors flex items-center gap-1">
          <IconChevronLeft className="w-6 h-6" />
          <span>Menu</span>
        </button>
        <div className="text-right">
          <p className="text-2xl font-bold text-orange-400">Models</p>
          <p className="text-sm text-gray-400">
            Download required files
          </p>
        </div>
      </div>

      <div className="bg-black/50 p-6 rounded-xl border border-gray-700">
        <h3 className="text-xl font-semibold text-white mb-2">Getting Started with Models</h3>
        <p className="text-gray-400 leading-relaxed">
          As per the technical blueprint, this project uses a pre-trained Whisper model which you will then fine-tune with your own voice data. Download the base model below to begin. We recommend creating a `models/` directory in your project folder to store these files.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Pre-trained Model Card */}
        <div className="bg-gray-900 border border-gray-700 rounded-lg p-6 flex flex-col">
            <h4 className="text-lg font-bold text-orange-400">Pre-Trained Base Model</h4>
            <p className="text-sm text-gray-500 mb-3">Whisper Tiny (English only)</p>
            <div className="flex-grow space-y-2 text-gray-300">
               <p><span className="font-semibold">File:</span> ggml-tiny.en.bin</p>
               <p><span className="font-semibold">Size:</span> ~75 MB</p>
               <p className="text-sm text-gray-400 pt-2">This is the starting point for fine-tuning. Download and place it in your `models/` folder.</p>
            </div>
            <a 
                href={modelFileUrl}
                download="ggml-tiny.en.bin"
                className="mt-4 w-full bg-orange-500 hover:bg-orange-600 text-white font-semibold py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors text-center"
            >
                <IconDownload className="w-5 h-5" />
                <span>Download Model</span>
            </a>
        </div>

        {/* Fine-tuned Model Card */}
        <div className="bg-gray-900 border border-gray-700 rounded-lg p-6 flex flex-col">
            <h4 className="text-lg font-bold text-green-400">Your Fine-Tuned Model</h4>
            <p className="text-sm text-gray-500 mb-3">Your Custom Model</p>
            <div className="flex-grow space-y-2 text-gray-300">
                <p><span className="font-semibold">File:</span> fine_tuned_tiny.bin (example)</p>
                <p><span className="font-semibold">Size:</span> ~75 MB</p>
                <p className="text-sm text-gray-400 pt-2">This model will be created by you after collecting data and running the fine-tuning Python script from the blueprint.</p>
            </div>
             <div className="mt-4 w-full bg-gray-800 text-gray-400 font-semibold py-2 px-4 rounded-lg flex items-center justify-center gap-2 text-center">
                <span>User Generated</span>
            </div>
        </div>
      </div>
    </div>
  );
};