import React, { useState } from 'react';
import { PromptCategory, type Prompt } from '../types';
import { RecordingController } from './RecordingController';
import { IconChevronLeft, IconChevronRight, IconCheckCircle } from './icons';
import { saveRecording } from '../services/mockApiService';

interface PromptContainerProps {
  category: PromptCategory;
  prompts: Prompt[];
  onBack: () => void;
}

export const PromptContainer: React.FC<PromptContainerProps> = ({ category, prompts, onBack }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [transcription, setTranscription] = useState('');
  const [isComplete, setIsComplete] = useState(false);

  const currentPrompt = prompts[currentIndex];

  const handleNext = () => {
    if (currentIndex < prompts.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setTranscription('');
    } else {
      setIsComplete(true);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setTranscription('');
    }
  };

  const handleSave = async (blob: Blob) => {
    await saveRecording(blob, currentPrompt, category, transcription);
    handleNext();
  };
  
  const resetSession = () => {
    setCurrentIndex(0);
    setTranscription('');
    setIsComplete(false);
  }

  if (isComplete) {
    return (
        <div className="text-center py-10 flex flex-col items-center animate-fade-in">
            <IconCheckCircle className="w-24 h-24 text-green-400 mb-6" />
            <h2 className="text-3xl font-bold text-white mb-3">Category Complete!</h2>
            <p className="text-gray-400 max-w-md mx-auto mb-8">
                Thank you for completing the '{category}' section. Your contribution is valuable.
            </p>
            <div className="flex items-center gap-4">
                <button onClick={onBack} className="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-6 rounded-lg transition-colors">
                    Back to Menu
                </button>
                <button onClick={resetSession} className="bg-orange-500 hover:bg-orange-600 text-white font-semibold py-2 px-6 rounded-lg transition-colors">
                    Record Again
                </button>
            </div>
        </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <button onClick={onBack} className="text-gray-400 hover:text-white transition-colors flex items-center gap-1">
          <IconChevronLeft className="w-6 h-6" />
          <span>Menu</span>
        </button>
        <div className="text-right">
          <p className="text-2xl font-bold text-orange-400 capitalize">{category}</p>
          <p className="text-sm text-gray-400">
            Prompt {currentIndex + 1} of {prompts.length}
          </p>
        </div>
      </div>

      <div className="bg-black/50 p-6 rounded-xl border border-gray-700 min-h-[120px] flex items-center justify-center">
        <p className="text-xl md:text-2xl font-medium text-center text-white leading-relaxed">
          {currentPrompt.text}
        </p>
      </div>

      {category === PromptCategory.Questions && (
        <div className="flex flex-col gap-2">
            <label htmlFor="transcription" className="text-sm font-medium text-gray-400">Type your spoken response here:</label>
            <textarea
            id="transcription"
            value={transcription}
            onChange={(e) => setTranscription(e.target.value)}
            placeholder="After recording, please type what you said..."
            className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-orange-500 focus:outline-none transition"
            rows={3}
            />
        </div>
      )}

      <RecordingController
        key={currentPrompt.id}
        onSave={handleSave}
        isTextRequired={category === PromptCategory.Questions}
        textValue={transcription}
      />

      <div className="flex justify-between items-center mt-4">
        <button
          onClick={handlePrev}
          disabled={currentIndex === 0}
          className="flex items-center gap-2 px-4 py-2 bg-gray-800 text-white rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-700 transition-colors"
        >
          <IconChevronLeft className="w-5 h-5" />
          <span>Previous</span>
        </button>
        <button
          onClick={handleNext}
          className="flex items-center gap-2 px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors"
        >
          <span>{currentIndex === prompts.length - 1 ? 'Finish' : 'Next Prompt'}</span>
          <IconChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};