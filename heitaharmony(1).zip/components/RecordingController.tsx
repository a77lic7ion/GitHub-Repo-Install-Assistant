
import React, { useState, useRef, useEffect } from 'react';
import type { RecordingStatus } from '../types';
import { IconMicrophone, IconStop, IconSave, IconTrash, IconXCircle } from './icons';

interface RecordingControllerProps {
  onSave: (blob: Blob) => Promise<void>;
  isTextRequired: boolean;
  textValue: string;
}

export const RecordingController: React.FC<RecordingControllerProps> = ({ onSave, isTextRequired, textValue }) => {
  const [status, setStatus] = useState<RecordingStatus>('idle');
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [error, setError] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioUrl = audioBlob ? URL.createObjectURL(audioBlob) : null;

  const handleDiscard = () => {
    setAudioBlob(null);
    setStatus('idle');
    setError(null);
  };

  // Clean up Object URL when component unmounts or blob changes
  useEffect(() => {
    return () => {
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
    };
  }, [audioUrl]);

  const getMimeType = () => {
      if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          return 'audio/webm;codecs=opus';
      } else if (MediaRecorder.isTypeSupported('audio/webm')) {
          return 'audio/webm';
      } else {
          return 'audio/mp4'; // Fallback
      }
  }

  const startRecording = async () => {
    // Reset previous states
    setError(null);
    setAudioBlob(null);

    // --- Perform all checks just-in-time on user action ---

    // 1. Check for secure context (HTTPS)
    if (!window.isSecureContext) {
      setError('Microphone access is only available on secure (HTTPS) websites.');
      setStatus('error');
      return;
    }

    // 2. Check for browser support
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setError('Media Devices API not supported in this browser.');
      setStatus('error');
      return;
    }

    // 3. Request permission and start recording
    setStatus('permission');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setStatus('recording');
      mediaRecorderRef.current = new MediaRecorder(stream, { mimeType: getMimeType() });
      audioChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorderRef.current.onstop = () => {
        const mimeType = mediaRecorderRef.current?.mimeType || 'audio/webm';
        const blob = new Blob(audioChunksRef.current, { type: mimeType });
        setAudioBlob(blob);
        setStatus('stopped');
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorderRef.current.start();
    } catch (err) {
      console.error("Error starting recording:", err);
      if (err instanceof Error) {
        let message = `Could not start recording. Please check your microphone and browser permissions.`;

        // Provide specific, helpful error messages
        switch(err.name) {
            case 'NotAllowedError':
            case 'PermissionDeniedError':
                message = 'Microphone permission denied. Please allow microphone access in your browser settings and try again.';
                break;
            case 'NotFoundError':
            case 'DevicesNotFoundError':
                message = 'No microphone was found. Please ensure a microphone is connected and working.';
                break;
            case 'NotReadableError':
            case 'TrackStartError':
                message = 'The microphone is currently in use by another application or tab. Please close it and try again.';
                break;
        }
        setError(message);
      } else {
        setError('An unknown error occurred while starting the recording.');
      }
      setStatus('error');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && status === 'recording') {
      mediaRecorderRef.current.stop();
    }
  };

  const handleSave = async () => {
    if (audioBlob) {
      setStatus('saving');
      await onSave(audioBlob);
    }
  };

  const isSaveDisabled = status === 'saving' || (isTextRequired && !textValue.trim());

  const renderControls = () => {
    switch (status) {
      case 'idle':
      case 'error': // Show record button even on error to allow retry
        return (
          <button onClick={startRecording} className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-6 rounded-full flex items-center justify-center gap-3 transition-transform transform hover:scale-105 shadow-lg">
            <IconMicrophone className="w-6 h-6" />
            <span>Start Recording</span>
          </button>
        );
      case 'permission':
         return (
             <div className="text-center text-gray-400">
                Requesting microphone permission... Check your browser's address bar for a prompt.
             </div>
         );
      case 'recording':
        return (
          <button onClick={stopRecording} className="bg-red-500 hover:bg-red-600 text-white font-bold py-3 px-6 rounded-full flex items-center justify-center gap-3 transition-transform transform hover:scale-105 shadow-lg animate-pulse">
            <IconStop className="w-6 h-6" />
            <span>Stop Recording</span>
          </button>
        );
      case 'stopped':
        return (
          <div className="flex flex-col items-center justify-center gap-4 w-full">
            {audioUrl && <audio src={audioUrl} controls className="w-full rounded-full" />}
            <div className="flex flex-col sm:flex-row items-center gap-4 w-full mt-4">
              <button onClick={handleDiscard} className="w-full sm:w-auto bg-gray-700 hover:bg-gray-600 text-white font-semibold py-3 px-5 rounded-lg flex items-center justify-center gap-2 transition-colors" title="Discard recording">
                <IconTrash className="w-5 h-5" />
                <span>Discard</span>
              </button>
              <button onClick={handleSave} disabled={isSaveDisabled} className="w-full sm:w-auto bg-green-500 hover:bg-green-600 text-white font-semibold py-3 px-5 rounded-lg flex items-center justify-center gap-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed" title={isSaveDisabled && isTextRequired ? 'Please type your response before saving' : 'Save recording'}>
                <IconSave className="w-5 h-5" />
                <span>Save & Next</span>
              </button>
            </div>
          </div>
        );
       case 'saving':
            return <div className="text-center text-gray-400">Saving...</div>;
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col items-center justify-center gap-4 bg-gray-900 p-6 rounded-xl border border-gray-700">
        {error && status === 'error' && (
             <div className="w-full bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg relative flex flex-col items-center gap-3 text-center" role="alert">
                <div className="flex items-center gap-2">
                    <IconXCircle className="w-6 h-6 flex-shrink-0"/>
                    <span className="font-bold">Microphone Error</span>
                </div>
                <p className="text-sm">{error}</p>
            </div>
        )}
        <div className="flex items-center justify-center w-full">
            {renderControls()}
        </div>
    </div>
  );
};
