
import React, { useState } from 'react';
import { IconMicrophone, IconList, IconCheckCircle, IconChevronRight } from './icons';

interface WelcomeSlidesProps {
    onComplete: () => void;
}

const slideContent = [
    {
        icon: IconMicrophone,
        title: "Welcome to HeitaHarmony",
        text: "Your voice can shape the future of AI. Help us build speech recognition that understands every South African accent."
    },
    {
        icon: IconList,
        title: "How It Works: Choose a Category",
        text: "Select from sentences, questions, or passages. Each category helps the AI learn in different ways."
    },
    {
        icon: IconMicrophone,
        title: "How It Works: Read & Record",
        text: "Simply read the text shown on the screen and record your voice. It's that easy to contribute."
    },
    {
        icon: IconCheckCircle,
        title: "Make a Real Impact",
        text: "Every recording you submit helps make technology more inclusive and accessible for all South Africans."
    }
];


export const WelcomeSlides: React.FC<WelcomeSlidesProps> = ({ onComplete }) => {
    const [currentSlide, setCurrentSlide] = useState(0);
    const isLastSlide = currentSlide === slideContent.length - 1;

    const handleNext = () => {
        if (isLastSlide) {
            onComplete();
        } else {
            setCurrentSlide(currentSlide + 1);
        }
    };

    const { icon: Icon, title, text } = slideContent[currentSlide];

    return (
        <div className="flex flex-col items-center justify-between text-center p-4 h-full min-h-[450px] animate-fade-in">
            <div className="absolute top-4 right-4">
                <button
                    onClick={onComplete}
                    className="text-gray-400 hover:text-white text-sm font-semibold transition-colors"
                >
                    Skip
                </button>
            </div>
            
            <div className="flex flex-col items-center justify-center flex-grow">
                <Icon className="w-24 h-24 mx-auto text-orange-400 mb-6" />
                <h2 className="text-3xl font-bold text-white mb-3">{title}</h2>
                <p className="text-gray-300 max-w-md mx-auto">
                    {text}
                </p>
            </div>

            <div className="w-full flex flex-col items-center gap-6 mt-6">
                 <div className="flex justify-center gap-2">
                    {slideContent.map((_, index) => (
                        <div
                            key={index}
                            className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${currentSlide === index ? 'bg-orange-500 scale-110' : 'bg-gray-600'}`}
                        />
                    ))}
                </div>
                <button 
                    onClick={handleNext} 
                    className="w-full max-w-xs bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-6 rounded-full flex items-center justify-center gap-3 transition-transform transform hover:scale-105 shadow-lg"
                >
                    <span>{isLastSlide ? "Get Started" : "Next"}</span>
                    {!isLastSlide && <IconChevronRight className="w-5 h-5" />}
                </button>
            </div>
        </div>
    );
};
