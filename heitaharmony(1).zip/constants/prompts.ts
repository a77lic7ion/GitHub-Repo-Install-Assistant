
import type { Prompt } from '../types';

const SABE_SENTENCES: string[] = [
  "Eish, the spaza shop is closed now-now.",
  "Sharp, I'll meet you at the robot.",
  "Heita, how's it going, my friend?",
  "Hawu, the taxi is late again!",
  "Ngiyabonga for fixing my phone.",
  "Amandla to the people in the struggle.",
  "Sawubona, let's braai some boerewors.",
  "Is it? You saw a kudu in the veld?",
  "The pap is ready for the braai.",
  "I'm going to the shebeen for a jol.",
  "Now-now, I'll fetch the bakkie.",
  "Eish, the geyser is broken again.",
  "Sharp-sharp, let's start the meeting.",
  "The laaitie is playing soccer outside.",
  "Heita, pass me a cold Castle.",
  "The rand is dropping fast, hawu!",
  "I saw a nyala near the vlei.",
  "Let's dance to some kwaito tonight.",
  "Ngiyabonga, the food is lekker.",
  "Is it? The match is on TV now?",
  "The amapiano beat is proper sharp.",
  "Eish, my chommie forgot the braai pack.",
  "Sawubona, let's go to the rank.",
  "Hawu, the airtime ran out again.",
  "Sharp, the taxi is waiting now-now.",
  "I bought vetkoek at the spaza shop.",
  "The shebeen plays lekker kwaito vibes.",
  "Ngiyabonga for the lift, my boet.",
  "Is it? The bakkie needs a new tyre.",
  "Heita, let's jol at the tavern.",
  "The pap and chakalaka taste amazing.",
  "Eish, the load shedding is back.",
  "Sharp-sharp, I'll call you now-now.",
  "The laaitie loves amapiano music.",
  "Sawubona, pass the boerewors roll.",
  "Hawu, the robot is out of order.",
  "Amandla, we stand together always.",
  "The vlei is dry this season.",
  "Ngiyabonga for the cold drink.",
  "Is it? The match starts at six.",
  "Eish, the taxi rank is hectic.",
  "Sharp, let's braai at my place.",
  "Heita, the kwaito track is fire.",
  "Now-now, I'll grab my phone.",
  "The spaza sells lekker sweets.",
  "Hawu, the geyser burst again!",
  "Sharp-sharp, we're ready to roll.",
  "Ngiyabonga for the rugby tickets.",
  "The shebeen is jumping tonight.",
  "Is it? The rand crashed again?",
];

const GENERAL_SENTENCES: string[] = [
  "The big dwarf only jumps.",
  "Quick foxes climb steep hills.",
  "She sells seashells by the seashore.",
  "Peter Piper picked a peck of pickled peppers.",
  "The cat chased the mouse around the house.",
  "The sun always sets in the west.",
  "A quick brown dog jumps over the lazy fox.",
  "The early bird catches the worm.",
  "Honesty is the best policy.",
  "Actions speak louder than words.",
  // Add 140 more general sentences for a full dataset
];

const SABE_QUESTIONS: string[] = [
  "What's the most lekker thing to eat at a braai?",
  "Which township vibe do you love the most?",
  "What slang word do you say all the time?",
  "Where do you go for a proper jol?",
  "What's your favorite kwaito or amapiano song?",
  "What's the best thing to buy at a spaza shop?",
  "How do you greet your chommie in the morning?",
];

const GENERAL_QUESTIONS: string[] = [
  "What's your favorite color, and why?",
  "Which animal makes the best pet?",
  "What food do you eat for breakfast?",
  "Name a city you want to visit.",
  "What's your favorite season?",
  "Which sport do you enjoy most?",
  "What music genre do you listen to?",
  "Name a book or movie you love.",
];

const SABE_PASSAGES: string[] = [
  "The shebeen was buzzing with kwaito music as the sun set over the township. Heita, my laaitie shouted, grabbing a cold one. Eish, the vibe was sharp-sharp, with everyone dancing now-now. Someone yelled, “Ngiyabonga for the pap!” as plates piled high. The night was lekker, full of amandla and joy.",
  "I hopped into the taxi by the robot, saying sawubona to the driver. Hawu, the music was loud, amapiano blasting through the speakers. We sped past the spaza shop and the veld, reaching the rank now-now. “Sharp,” I said, paying my rand. The township never sleeps.",
  "The braai was lit, with boerewors sizzling and the smell of pap in the air. Eish, my chommie brought a cold Castle. Sharp-sharp, we danced to amapiano under the stars. “Ngiyabonga for the vibe,” I said, as the laaities played nearby. The night was proper lekker.",
];

const GENERAL_PASSAGES: string[] = [
  "The narrow path wound through the dense forest, where tall trees stretched toward the sky. Birds chirped in the branches, and a gentle breeze carried the scent of pine. A small stream bubbled nearby, its water clear and cool. Tiny flowers bloomed along the trail.",
  "Perched on a cliff, the old lighthouse stood against the stormy sea. Its beacon flashed, guiding ships to shore. The keeper climbed the spiral stairs daily, checking the lamp. At night, the light cut through the fog, a symbol of hope.",
  "Every morning, I wake to my alarm clock. I brew coffee and watch the sunrise. The warm mug feels comforting. After breakfast, I check emails and plan my day. A quick walk around the block clears my mind before work begins.",
  "The beach was calm, with waves lapping at the shore. Seagulls soared above, and the sand felt warm underfoot. I picked up a smooth shell and watched the sunset. The ocean whispered peace, a perfect end to the day.",
];


// Combine and map to Prompt[] format
export const SENTENCES: Prompt[] = [...SABE_SENTENCES, ...GENERAL_SENTENCES].map((text, i) => ({ id: `s${i + 1}`, text }));
export const QUESTIONS: Prompt[] = [...SABE_QUESTIONS, ...GENERAL_QUESTIONS].map((text, i) => ({ id: `q${i + 1}`, text }));
export const PASSAGES: Prompt[] = [...SABE_PASSAGES, ...GENERAL_PASSAGES].map((text, i) => ({ id: `p${i + 1}`, text }));
