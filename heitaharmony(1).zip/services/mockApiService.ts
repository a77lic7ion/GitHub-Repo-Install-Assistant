import { PromptCategory, type Prompt } from '../types';

// Mock API service to simulate saving recordings.
// In a real application, this would send data to a backend server.

export const saveRecording = async (
  blob: Blob,
  prompt: Prompt,
  category: PromptCategory,
  transcription: string
): Promise<void> => {
  console.log('%c--- Mock API: Saving Recording ---', 'color: #0ea5e9; font-weight: bold;');
  
  const formData = new FormData();
  // The blueprint mentions converting to WAV on the backend, but we'll name it .wav here for consistency.
  // The browser will likely record in webm or mp4 format.
  const fileName = `${prompt.id}.wav`;
  
  formData.append('audio', blob, fileName);
  formData.append('userId', 'user123'); // As per blueprint
  formData.append('promptId', prompt.id);
  
  // For 'questions', the 'text' is the user's transcription.
  // For others, it's the prompt text itself.
  const textToSave = category === PromptCategory.Questions ? transcription : prompt.text;
  formData.append('text', textToSave);

  console.log('Category:', category);
  console.log('Prompt ID:', prompt.id);
  console.log('Prompt Text:', prompt.text);
  if (category === PromptCategory.Questions) {
    console.log('User Transcription:', transcription);
  }
  console.log('Audio Blob:', blob);
  console.log('File Name:', fileName);
  console.log('FormData prepared. In a real app, this would be sent via POST to /upload');
  
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));

  console.log('%c--- Mock API: Save Complete ---', 'color: #22c55e; font-weight: bold;');
  // In a real app, you would handle success/error responses from the server.
};