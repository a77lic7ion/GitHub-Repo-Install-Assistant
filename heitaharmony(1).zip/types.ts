
export enum PromptCategory {
  Sentences = 'sentences',
  Questions = 'questions',
  Passages = 'passages',
  Models = 'models',
}

export interface Prompt {
  id: string;
  text: string;
}

export type RecordingStatus = 'idle' | 'permission' | 'recording' | 'stopped' | 'saving' | 'error';
